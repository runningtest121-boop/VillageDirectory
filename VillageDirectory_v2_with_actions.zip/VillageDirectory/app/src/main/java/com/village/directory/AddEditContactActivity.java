package com.village.directory;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Arrays;
import java.util.List;

public class AddEditContactActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private SessionManager session;
    private long contactId = -1;

    private TextInputEditText etName, etPhone, etAddress, etNotes;
    private AutoCompleteTextView etCategory;

    private static final List<String> DEFAULT_CATEGORIES = Arrays.asList(
            "Emergency","Medical","Government","Education",
            "Utilities","Community","Services","Business","Other"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db      = DatabaseHelper.getInstance(this);
        session = new SessionManager(this);

        // Security: if not admin, bounce back immediately
        if (!session.isAdmin()) {
            Toast.makeText(this, "⛔ Admin access only", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_add_edit_contact);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etName     = findViewById(R.id.etName);
        etPhone    = findViewById(R.id.etPhone);
        etCategory = findViewById(R.id.etCategory);
        etAddress  = findViewById(R.id.etAddress);
        etNotes    = findViewById(R.id.etNotes);
        Button btnSave = findViewById(R.id.btnSave);

        etCategory.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, DEFAULT_CATEGORIES));

        contactId = getIntent().getLongExtra("contact_id", -1);
        if (contactId != -1) {
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Edit Contact");
            Contact c = db.getContact(contactId);
            if (c != null) {
                etName.setText(c.getName());
                etPhone.setText(c.getPhone());
                etCategory.setText(c.getCategory());
                etAddress.setText(c.getAddress());
                etNotes.setText(c.getNotes());
            }
        } else {
            if (getSupportActionBar() != null) getSupportActionBar().setTitle("Add Contact");
        }

        btnSave.setOnClickListener(v -> saveContact());
    }

    private void saveContact() {
        String name  = text(etName);
        String phone = text(etPhone);
        String cat   = etCategory.getText().toString().trim();
        String addr  = text(etAddress);
        String notes = text(etNotes);

        if (name.isEmpty())  { etName.setError("Name is required");  return; }
        if (phone.isEmpty()) { etPhone.setError("Phone is required"); return; }

        Contact c = new Contact();
        c.setName(name); c.setPhone(phone); c.setCategory(cat);
        c.setAddress(addr); c.setNotes(notes);

        if (contactId == -1) {
            db.addContact(c);
            Toast.makeText(this, "✅ Contact added!", Toast.LENGTH_SHORT).show();
        } else {
            c.setId(contactId);
            db.updateContact(c);
            Toast.makeText(this, "✅ Contact updated!", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private String text(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        return super.onOptionsItemSelected(item);
    }
}
