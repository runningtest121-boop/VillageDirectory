package com.village.directory;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ContactDetailActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private SessionManager session;
    private Contact contact;
    private long contactId;

    private static final String[] CAT_COLORS = {
            "#E53935","#8E24AA","#1E88E5","#00897B",
            "#F4511E","#6D4C41","#039BE5","#43A047",
            "#FFB300","#546E7A"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        db        = DatabaseHelper.getInstance(this);
        session   = new SessionManager(this);
        contactId = getIntent().getLongExtra("contact_id", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        loadContact();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadContact();
    }

    private void loadContact() {
        contact = db.getContact(contactId);
        if (contact == null) { finish(); return; }

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(contact.getName());

        TextView tvAvatar   = findViewById(R.id.tvAvatar);
        TextView tvName     = findViewById(R.id.tvName);
        TextView tvPhone    = findViewById(R.id.tvPhone);
        TextView tvCategory = findViewById(R.id.tvCategory);
        TextView tvAddress  = findViewById(R.id.tvAddress);
        TextView tvNotes    = findViewById(R.id.tvNotes);

        ImageButton btnCall      = findViewById(R.id.btnCall);
        ImageButton btnSms       = findViewById(R.id.btnSms);
        ImageButton btnWhatsApp  = findViewById(R.id.btnWhatsApp);
        ImageButton btnFav       = findViewById(R.id.btnFav);

        // Admin-only action row
        LinearLayout adminActions = findViewById(R.id.adminActions);

        tvAvatar.setText(contact.getInitials());
        tvAvatar.setBackgroundColor(Color.parseColor(colorFor(contact.getCategory())));
        tvName.setText(contact.getName());
        tvPhone.setText(contact.getPhone());
        tvCategory.setText(contact.getCategory() != null ? contact.getCategory() : "—");
        tvAddress.setText(notEmpty(contact.getAddress()));
        tvNotes.setText(notEmpty(contact.getNotes()));

        // Favourite
        updateFavIcon(btnFav);
        btnFav.setOnClickListener(v -> {
            db.toggleFavorite(contact.getId());
            contact.setFavorite(!contact.isFavorite());
            updateFavIcon(btnFav);
        });

        // Call
        btnCall.setOnClickListener(v ->
                startActivity(new Intent(Intent.ACTION_DIAL,
                        Uri.parse("tel:" + contact.getPhone()))));

        // SMS
        btnSms.setOnClickListener(v ->
                startActivity(new Intent(Intent.ACTION_SENDTO,
                        Uri.parse("smsto:" + contact.getPhone()))));

        // WhatsApp
        btnWhatsApp.setOnClickListener(v -> openWhatsApp(contact.getPhone()));

        // Admin-only: Edit / Delete buttons
        if (session.isAdmin()) {
            adminActions.setVisibility(View.VISIBLE);

            findViewById(R.id.btnEdit).setOnClickListener(v -> {
                Intent i = new Intent(this, AddEditContactActivity.class);
                i.putExtra("contact_id", contactId);
                startActivity(i);
            });

            findViewById(R.id.btnDelete).setOnClickListener(v ->
                    new AlertDialog.Builder(this)
                            .setTitle("Delete Contact")
                            .setMessage("Delete \"" + contact.getName() + "\"?")
                            .setPositiveButton("Delete", (d, w) -> {
                                db.deleteContact(contactId);
                                Toast.makeText(this, "Contact deleted", Toast.LENGTH_SHORT).show();
                                finish();
                            })
                            .setNegativeButton("Cancel", null)
                            .show());
        } else {
            adminActions.setVisibility(View.GONE);
        }
    }

    private void updateFavIcon(ImageButton btn) {
        btn.setImageResource(contact.isFavorite()
                ? android.R.drawable.btn_star_big_on
                : android.R.drawable.btn_star_big_off);
    }

    private void openWhatsApp(String phone) {
        // Strip non-digits and ensure international format
        String cleaned = phone.replaceAll("[^0-9+]", "");
        if (!cleaned.startsWith("+")) cleaned = "+91" + cleaned; // default country code India
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + cleaned.replace("+", "")));
            i.setPackage("com.whatsapp");
            startActivity(i);
        } catch (Exception e) {
            // WhatsApp not installed — open in browser
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + cleaned.replace("+", ""))));
        }
    }

    private String notEmpty(String s) {
        return (s != null && !s.isEmpty()) ? s : "—";
    }

    private String colorFor(String category) {
        if (category == null) return CAT_COLORS[9];
        return CAT_COLORS[Math.abs(category.hashCode()) % CAT_COLORS.length];
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Admin gets edit option in toolbar too
        if (session.isAdmin()) getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) { finish(); return true; }
        if (id == R.id.action_edit && session.isAdmin()) {
            Intent i = new Intent(this, AddEditContactActivity.class);
            i.putExtra("contact_id", contactId);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
