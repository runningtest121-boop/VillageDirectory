package com.village.directory;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private final Context context;
    private List<Contact> contacts;
    private final DatabaseHelper db;
    private final boolean isAdmin;

    private static final String[] CAT_COLORS = {
            "#E53935","#8E24AA","#1E88E5","#00897B",
            "#F4511E","#6D4C41","#039BE5","#43A047",
            "#FFB300","#546E7A"
    };

    public ContactAdapter(Context context, List<Contact> contacts, boolean isAdmin) {
        this.context  = context;
        this.contacts = contacts;
        this.db       = DatabaseHelper.getInstance(context);
        this.isAdmin  = isAdmin;
    }

    public void updateList(List<Contact> newList) {
        this.contacts = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_contact, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Contact c = contacts.get(position);

        h.tvInitials.setText(c.getInitials());
        h.tvInitials.setBackgroundColor(Color.parseColor(colorFor(c.getCategory())));
        h.tvName.setText(c.getName());
        h.tvPhone.setText(c.getPhone());
        h.tvCategory.setText(c.getCategory() != null ? c.getCategory() : "");

        // Role badge: admin shows shield, user shows person icon
        if (isAdmin) {
            h.tvRoleBadge.setVisibility(View.GONE); // admin doesn't need badge in list
        } else {
            h.tvRoleBadge.setVisibility(View.GONE);
        }

        // Favourite star
        h.btnFav.setImageResource(c.isFavorite()
                ? android.R.drawable.btn_star_big_on
                : android.R.drawable.btn_star_big_off);
        h.btnFav.setOnClickListener(v -> {
            db.toggleFavorite(c.getId());
            c.setFavorite(!c.isFavorite());
            notifyItemChanged(position);
        });

        // Call button - always visible
        h.btnCall.setOnClickListener(v ->
                context.startActivity(new Intent(Intent.ACTION_DIAL,
                        Uri.parse("tel:" + c.getPhone()))));

        // Open detail on card click
        h.card.setOnClickListener(v -> {
            Intent i = new Intent(context, ContactDetailActivity.class);
            i.putExtra("contact_id", c.getId());
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() { return contacts.size(); }

    private String colorFor(String category) {
        if (category == null) return CAT_COLORS[9];
        return CAT_COLORS[Math.abs(category.hashCode()) % CAT_COLORS.length];
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView card;
        TextView tvInitials, tvName, tvPhone, tvCategory, tvRoleBadge;
        ImageButton btnCall, btnFav;

        ViewHolder(View v) {
            super(v);
            card        = v.findViewById(R.id.card);
            tvInitials  = v.findViewById(R.id.tvInitials);
            tvName      = v.findViewById(R.id.tvName);
            tvPhone     = v.findViewById(R.id.tvPhone);
            tvCategory  = v.findViewById(R.id.tvCategory);
            tvRoleBadge = v.findViewById(R.id.tvRoleBadge);
            btnCall     = v.findViewById(R.id.btnCall);
            btnFav      = v.findViewById(R.id.btnFav);
        }
    }
}
