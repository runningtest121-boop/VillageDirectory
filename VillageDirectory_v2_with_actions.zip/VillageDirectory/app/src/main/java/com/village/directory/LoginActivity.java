package com.village.directory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private SessionManager session;

    private TextInputEditText etEmail, etPassword;
    private Button btnLogin;
    private ProgressBar progressBar;
    private TextView tvRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth   = FirebaseAuth.getInstance();
        session = new SessionManager(this);

        // If already signed in via Firebase AND we have a local session, skip login
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null && session.isLoggedIn()) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_login);

        etEmail     = findViewById(R.id.etEmail);
        etPassword  = findViewById(R.id.etPassword);
        btnLogin    = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);
        tvRole      = findViewById(R.id.tvRole);

        // Live hint: show "Admin" tag when email matches admin address
        etEmail.setOnFocusChangeListener((v, hasFocus) -> updateRoleHint());
        etEmail.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            public void onTextChanged(CharSequence s, int i, int b, int c) { updateRoleHint(); }
            public void afterTextChanged(android.text.Editable s) {}
        });

        btnLogin.setOnClickListener(v -> loginUser());
    }

    private void updateRoleHint() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        if (email.equalsIgnoreCase(SessionManager.ADMIN_EMAIL)) {
            tvRole.setVisibility(View.VISIBLE);
            tvRole.setText("🛡  Signing in as Administrator");
            tvRole.setTextColor(getResources().getColor(R.color.admin_color, null));
        } else if (!email.isEmpty()) {
            tvRole.setVisibility(View.VISIBLE);
            tvRole.setText("👤  Signing in as Village User");
            tvRole.setTextColor(getResources().getColor(R.color.primary, null));
        } else {
            tvRole.setVisibility(View.GONE);
        }
    }

    private void loginUser() {
        String email    = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString() : "";

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Enter email");
            etEmail.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Enter password");
            etPassword.requestFocus();
            return;
        }

        setLoading(true);

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    setLoading(false);
                    if (task.isSuccessful()) {
                        session.saveSession(email);
                        Toast.makeText(this,
                                session.isAdmin() ? "Welcome, Admin! 🛡" : "Welcome! 👋",
                                Toast.LENGTH_SHORT).show();
                        goToMain();
                    } else {
                        String msg = task.getException() != null
                                ? task.getException().getMessage()
                                : "Login failed";
                        Toast.makeText(this, "❌ " + msg, Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? "Signing in…" : "Sign In");
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
