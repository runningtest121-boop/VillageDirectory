package com.village.directory;

public class Contact {
    private long id;
    private String name;
    private String phone;
    private String category;
    private String address;
    private String notes;
    private boolean isFavorite;

    public Contact() {}

    public Contact(long id, String name, String phone, String category,
                   String address, String notes, boolean isFavorite) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.category = category;
        this.address = address;
        this.notes = notes;
        this.isFavorite = isFavorite;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public String getInitials() {
        if (name == null || name.isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        if (parts.length >= 2)
            return String.valueOf(parts[0].charAt(0)).toUpperCase()
                    + String.valueOf(parts[1].charAt(0)).toUpperCase();
        return String.valueOf(name.charAt(0)).toUpperCase();
    }
}
