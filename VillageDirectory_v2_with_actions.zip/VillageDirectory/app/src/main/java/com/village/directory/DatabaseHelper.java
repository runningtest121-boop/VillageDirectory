package com.village.directory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME    = "VillageDirectory.db";
    private static final int    DB_VERSION = 1;
    private static final String TABLE      = "contacts";
    private static final String C_ID       = "id";
    private static final String C_NAME     = "name";
    private static final String C_PHONE    = "phone";
    private static final String C_CATEGORY = "category";
    private static final String C_ADDRESS  = "address";
    private static final String C_NOTES    = "notes";
    private static final String C_FAV      = "is_favorite";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context ctx) {
        if (instance == null) instance = new DatabaseHelper(ctx.getApplicationContext());
        return instance;
    }

    private DatabaseHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + "("
                + C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + C_NAME + " TEXT NOT NULL,"
                + C_PHONE + " TEXT NOT NULL,"
                + C_CATEGORY + " TEXT,"
                + C_ADDRESS + " TEXT,"
                + C_NOTES + " TEXT,"
                + C_FAV + " INTEGER DEFAULT 0)");
        seedData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    private void seedData(SQLiteDatabase db) {
        String[][] seeds = {
            {"Village Head",        "0700000001","Government","Village Office",   "Chief of the village"},
            {"Police Station",      "0700000002","Emergency", "Main Road",        "24/7 emergency line"},
            {"Health Clinic",       "0700000003","Medical",   "Near Market",      "Primary health care"},
            {"Fire Brigade",        "0700000004","Emergency", "Town Centre",      "Fire & rescue"},
            {"Primary School",      "0700000005","Education", "School Road",      "Headteacher office"},
            {"Water Supply Office", "0700000006","Utilities", "North Block",      "Report water issues"},
            {"Electricity Board",   "0700000007","Utilities", "South Block",      "Report power cuts"},
            {"Community Centre",    "0700000008","Community", "Village Square",   "Events & meetings"},
            {"Ambulance Service",   "0700000009","Medical",   "District Hospital","Emergency ambulance"},
            {"Post Office",         "0700000010","Services",  "Market Area",      "Mail & parcels"},
        };
        for (String[] s : seeds) {
            ContentValues cv = new ContentValues();
            cv.put(C_NAME, s[0]); cv.put(C_PHONE, s[1]); cv.put(C_CATEGORY, s[2]);
            cv.put(C_ADDRESS, s[3]); cv.put(C_NOTES, s[4]); cv.put(C_FAV, 0);
            db.insert(TABLE, null, cv);
        }
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    public long addContact(Contact c) {
        return getWritableDatabase().insert(TABLE, null, toValues(c));
    }

    public boolean updateContact(Contact c) {
        return getWritableDatabase().update(TABLE, toValues(c),
                C_ID + "=?", new String[]{String.valueOf(c.getId())}) > 0;
    }

    public boolean deleteContact(long id) {
        return getWritableDatabase().delete(TABLE, C_ID + "=?",
                new String[]{String.valueOf(id)}) > 0;
    }

    public Contact getContact(long id) {
        Cursor c = getReadableDatabase().query(TABLE, null, C_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        Contact contact = null;
        if (c.moveToFirst()) contact = fromCursor(c);
        c.close();
        return contact;
    }

    public List<Contact> getAllContacts() {
        return query(null, null);
    }

    public List<Contact> getFavorites() {
        return query(C_FAV + "=1", null);
    }

    public List<Contact> getByCategory(String cat) {
        return query(C_CATEGORY + "=?", new String[]{cat});
    }

    public List<Contact> search(String q) {
        String like = "%" + q + "%";
        return query(C_NAME + " LIKE ? OR " + C_PHONE + " LIKE ? OR "
                + C_CATEGORY + " LIKE ? OR " + C_ADDRESS + " LIKE ?",
                new String[]{like, like, like, like});
    }

    public List<String> getCategories() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT DISTINCT " + C_CATEGORY + " FROM " + TABLE
                        + " WHERE " + C_CATEGORY + " IS NOT NULL ORDER BY " + C_CATEGORY, null);
        List<String> list = new ArrayList<>();
        while (c.moveToNext()) list.add(c.getString(0));
        c.close();
        return list;
    }

    public void toggleFavorite(long id) {
        Cursor c = getReadableDatabase().query(TABLE, new String[]{C_FAV},
                C_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (!c.moveToFirst()) { c.close(); return; }
        int cur = c.getInt(0); c.close();
        ContentValues cv = new ContentValues();
        cv.put(C_FAV, cur == 0 ? 1 : 0);
        getWritableDatabase().update(TABLE, cv, C_ID + "=?", new String[]{String.valueOf(id)});
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private List<Contact> query(String where, String[] args) {
        Cursor c = getReadableDatabase().query(TABLE, null, where, args, null, null, C_NAME + " ASC");
        List<Contact> list = new ArrayList<>();
        while (c.moveToNext()) list.add(fromCursor(c));
        c.close();
        return list;
    }

    private ContentValues toValues(Contact c) {
        ContentValues cv = new ContentValues();
        cv.put(C_NAME, c.getName());    cv.put(C_PHONE, c.getPhone());
        cv.put(C_CATEGORY, c.getCategory()); cv.put(C_ADDRESS, c.getAddress());
        cv.put(C_NOTES, c.getNotes());  cv.put(C_FAV, c.isFavorite() ? 1 : 0);
        return cv;
    }

    private Contact fromCursor(Cursor c) {
        return new Contact(
                c.getLong(c.getColumnIndexOrThrow(C_ID)),
                c.getString(c.getColumnIndexOrThrow(C_NAME)),
                c.getString(c.getColumnIndexOrThrow(C_PHONE)),
                c.getString(c.getColumnIndexOrThrow(C_CATEGORY)),
                c.getString(c.getColumnIndexOrThrow(C_ADDRESS)),
                c.getString(c.getColumnIndexOrThrow(C_NOTES)),
                c.getInt(c.getColumnIndexOrThrow(C_FAV)) == 1);
    }
}
