package com.village.directory;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Stores the current user's role (admin / user) in SharedPreferences
 * so every screen can quickly check permissions.
 */
public class SessionManager {

    private static final String PREF_NAME  = "VillageSession";
    private static final String KEY_EMAIL  = "email";
    private static final String KEY_ROLE   = "role";
    private static final String KEY_LOGGED = "loggedIn";

    public static final String ROLE_ADMIN = "admin";
    public static final String ROLE_USER  = "user";

    // The single admin e-mail address
    public static final String ADMIN_EMAIL = "gojiyapiyush@gmail.com";

    private final SharedPreferences prefs;

    public SessionManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveSession(String email) {
        String role = email.equalsIgnoreCase(ADMIN_EMAIL) ? ROLE_ADMIN : ROLE_USER;
        prefs.edit()
                .putBoolean(KEY_LOGGED, true)
                .putString(KEY_EMAIL, email)
                .putString(KEY_ROLE, role)
                .apply();
    }

    public void clearSession() {
        prefs.edit().clear().apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_LOGGED, false);
    }

    public boolean isAdmin() {
        return ROLE_ADMIN.equals(prefs.getString(KEY_ROLE, ROLE_USER));
    }

    public String getEmail() {
        return prefs.getString(KEY_EMAIL, "");
    }

    public String getRole() {
        return prefs.getString(KEY_ROLE, ROLE_USER);
    }
}
