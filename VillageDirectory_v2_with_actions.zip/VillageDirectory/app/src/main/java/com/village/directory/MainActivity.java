package com.village.directory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private SessionManager session;
    private ContactAdapter adapter;
    private RecyclerView recyclerView;
    private EditText etSearch;
    private ChipGroup chipGroup;
    private TextView tvEmpty;
    private String activeCategory = null;
    private boolean showFavoritesOnly = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db      = DatabaseHelper.getInstance(this);
        session = new SessionManager(this);

        // Redirect to login if not authenticated
        if (!session.isLoggedIn() || FirebaseAuth.getInstance().getCurrentUser() == null) {
            goToLogin();
            return;
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Show role in subtitle
        if (getSupportActionBar() != null) {
            getSupportActionBar().setSubtitle(session.isAdmin()
                    ? "🛡  Administrator" : "👤  Village User");
        }

        recyclerView = findViewById(R.id.recyclerView);
        etSearch     = findViewById(R.id.etSearch);
        chipGroup    = findViewById(R.id.chipGroup);
        tvEmpty      = findViewById(R.id.tvEmpty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ContactAdapter(this, db.getAllContacts(), session.isAdmin());
        recyclerView.setAdapter(adapter);

        buildCategoryChips();

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            public void onTextChanged(CharSequence s, int i, int b, int c) { filterContacts(); }
            public void afterTextChanged(Editable s) {}
        });

        // FAB — only admins can add contacts
        FloatingActionButton fab = findViewById(R.id.fab);
        if (session.isAdmin()) {
            fab.setVisibility(View.VISIBLE);
            fab.setOnClickListener(v ->
                    startActivity(new Intent(this, AddEditContactActivity.class)));
        } else {
            fab.setVisibility(View.GONE);
        }

        requestCallPermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (session.isLoggedIn()) {
            filterContacts();
            buildCategoryChips();
        }
    }

    private void buildCategoryChips() {
        chipGroup.removeAllViews();

        addChip("All", activeCategory == null && !showFavoritesOnly, () -> {
            activeCategory = null; showFavoritesOnly = false; filterContacts();
        });

        addChip("★ Favourites", showFavoritesOnly, () -> {
            showFavoritesOnly = true; activeCategory = null; filterContacts();
        });

        for (String cat : db.getCategories()) {
            addChip(cat, cat.equals(activeCategory), () -> {
                activeCategory = cat; showFavoritesOnly = false; filterContacts();
            });
        }
    }

    private void addChip(String label, boolean checked, Runnable onClick) {
        Chip chip = new Chip(this);
        chip.setText(label);
        chip.setCheckable(true);
        chip.setChecked(checked);
        chip.setOnClickListener(v -> onClick.run());
        chipGroup.addView(chip);
    }

    private void filterContacts() {
        String q = etSearch.getText().toString().trim();
        List<Contact> results;
        if (!q.isEmpty())             results = db.search(q);
        else if (showFavoritesOnly)   results = db.getFavorites();
        else if (activeCategory != null) results = db.getByCategory(activeCategory);
        else                          results = db.getAllContacts();

        adapter.updateList(results);
        tvEmpty.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_logout) {
            new AlertDialog.Builder(this)
                    .setTitle("Sign Out")
                    .setMessage("Are you sure you want to sign out?")
                    .setPositiveButton("Sign Out", (d, w) -> logout())
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        } else if (id == R.id.action_about) {
            String role = session.isAdmin() ? "Administrator 🛡" : "Village User 👤";
            new AlertDialog.Builder(this)
                    .setTitle("Village Directory")
                    .setMessage("Logged in as: " + session.getEmail()
                            + "\nRole: " + role
                            + "\n\nTap a contact to view details.\nTap ☎ to call directly.")
                    .setPositiveButton("OK", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        session.clearSession();
        goToLogin();
    }

    private void goToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void requestCallPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE}, 101);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                           @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
    }
}
